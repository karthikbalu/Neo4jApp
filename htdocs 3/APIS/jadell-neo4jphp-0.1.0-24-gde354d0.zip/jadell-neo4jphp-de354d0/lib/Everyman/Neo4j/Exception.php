<?php
namespace Everyman\Neo4j;

class Exception extends \Exception
{
}
